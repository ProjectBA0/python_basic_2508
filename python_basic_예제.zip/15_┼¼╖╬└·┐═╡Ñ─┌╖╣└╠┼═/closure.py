# closure.py

def mul3(n):
    return n*3

def mul5(n):
    return n*5

print(mul3(10))
print(mul5(10))
# 라인복사는 시프트 알트 아래화살표